import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, Navigation, Loader2, Coffee, Siren } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { ambilPetugas } from '../lib/accessCode'
import { ConfirmModal } from '../components/ConfirmModal'
import { ParasMap } from '../components/ParasMap'
import type { LokasiPoint } from '../components/ParasMap'
import apmLogo from '../assets/apm-logo.png'

const STORAGE_KEY = 'paras_jejak_active'

type Keadaan = 'biasa' | 'rehat' | 'kecemasan'

type SesiJejak = { id: string; negeri: string; keadaan?: Keadaan }

export function ParasJejak() {
  const navigate = useNavigate()
  const { negeri: negeriParam } = useParams<{ negeri: string }>()
  const negeri = decodeURIComponent(negeriParam ?? '')

  const [sedangJejak, setSedangJejak] = useState(false)
  const [mendapatkanGps, setMendapatkanGps] = useState(false)
  const [ralat, setRalat] = useState('')
  const [lokasiAwam, setLokasiAwam] = useState<LokasiPoint[]>([])
  const [posisiSaya, setPosisiSaya] = useState<[number, number] | null>(null)
  const [keadaan, setKeadaan] = useState<Keadaan>('biasa')
  const [sahkanKecemasan, setSahkanKecemasan] = useState(false)
  const [menukarKeadaan, setMenukarKeadaan] = useState(false)

  const trackingIdRef = useRef<string | null>(null)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // Center the map on the visitor's own position as soon as we can get it,
  // even before they start tracking.
  // Public map — anyone can see this, so it goes through the RPC
  // (RLS blocks direct table reads for anonymous visitors) and refreshes
  // by polling every 3s rather than a realtime subscription, since
  // Supabase Realtime also enforces the table's RLS for anon clients.
  useEffect(() => {
    async function muatSemula() {
      const { data } = await supabase.rpc('get_paras_lokasi_by_negeri', {
        p_negeri: negeri,
      })
      const semua = (data as LokasiPoint[]) ?? []
      setLokasiAwam(semua.filter((p) => p.status === 'aktif'))
    }

    muatSemula()
    const poll = setInterval(muatSemula, 3000)
    return () => clearInterval(poll)
  }, [negeri])

  // Restore an in-progress tracking session, but only if it belongs to
  // this same negeri — otherwise a stray session for another negeri
  // shouldn't silently resume on the wrong page.
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY)
    if (!saved) return

    try {
      const sesi = JSON.parse(saved) as SesiJejak
      if (sesi.negeri !== negeri) return

      trackingIdRef.current = sesi.id
      setSedangJejak(true)
      setKeadaan(sesi.keadaan ?? 'biasa')

      hantarPosisi()
      intervalRef.current = setInterval(hantarPosisi, 500)
    } catch {
      localStorage.removeItem(STORAGE_KEY)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [negeri])

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [])

  function hantarPosisi() {
    if (!trackingIdRef.current) return

    const id = trackingIdRef.current

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        // Tracking may have been stopped while this GPS fix was still
        // in flight — don't let a late update reactivate it.
        if (trackingIdRef.current !== id) return

        const { latitude, longitude } = position.coords
        setPosisiSaya([latitude, longitude])
        const petugas = ambilPetugas()
        await supabase.rpc('track_paras_lokasi', {
          p_id: id,
          p_negeri: negeri,
          p_latitude: latitude,
          p_longitude: longitude,
          p_nama: petugas?.nama ?? null,
          p_pangkat: petugas?.pangkat ?? null,
          p_no_tel: petugas?.noTel ?? null,
        })
      },
      () => {
        setRalat('Tidak dapat mengesan lokasi. Sila benarkan akses GPS.')
        handleTamatJejak()
      },
    )
  }

  function handleMulaJejak() {
    if (!navigator.geolocation) {
      setRalat('Pelayar ini tidak menyokong GPS.')
      return
    }

    setRalat('')
    setMendapatkanGps(true)
    const id = crypto.randomUUID()

    // Wait for the FIRST location request (and its permission prompt) to
    // actually succeed before starting the repeating interval — starting
    // the interval immediately would fire overlapping requests while the
    // prompt is still open, and those get auto-rejected by the browser.
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords
        setPosisiSaya([latitude, longitude])
        setMendapatkanGps(false)

        trackingIdRef.current = id
        setSedangJejak(true)
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ id, negeri }))

        const petugas = ambilPetugas()
        await supabase.rpc('track_paras_lokasi', {
          p_id: id,
          p_negeri: negeri,
          p_latitude: latitude,
          p_longitude: longitude,
          p_nama: petugas?.nama ?? null,
          p_pangkat: petugas?.pangkat ?? null,
          p_no_tel: petugas?.noTel ?? null,
        })

        intervalRef.current = setInterval(hantarPosisi, 500)
      },
      () => {
        setMendapatkanGps(false)
        setRalat('Tidak dapat mengesan lokasi. Sila benarkan akses GPS.')
      },
    )
  }

  async function tukarKeadaan(baru: Keadaan) {
    const id = trackingIdRef.current
    if (!id) return

    const lama = keadaan
    setKeadaan(baru) // optimistic
    setMenukarKeadaan(true)
    setRalat('')

    const { error } = await supabase.rpc('set_paras_keadaan', { p_id: id, p_keadaan: baru })
    setMenukarKeadaan(false)

    if (error) {
      setKeadaan(lama)
      setRalat('Gagal mengemaskini keadaan. Sila cuba lagi.')
      return
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify({ id, negeri, keadaan: baru }))
  }

  function tekanRehat() {
    tukarKeadaan(keadaan === 'rehat' ? 'biasa' : 'rehat')
  }

  function tekanKecemasan() {
    // Turning an emergency OFF is immediate; turning it ON asks first.
    if (keadaan === 'kecemasan') tukarKeadaan('biasa')
    else setSahkanKecemasan(true)
  }

  async function handleTamatJejak() {
    if (intervalRef.current) clearInterval(intervalRef.current)
    intervalRef.current = null

    const id = trackingIdRef.current
    trackingIdRef.current = null // stop any in-flight GPS update from reviving this session

    if (id) {
      // Remove the pin straight away rather than waiting up to 3s for the
      // next poll — the RPC call below still confirms it on the server.
      setLokasiAwam((prev) => prev.filter((p) => p.id !== id))

      const { error } = await supabase.rpc('stop_paras_lokasi', { p_id: id })
      if (error) {
        setRalat('Gagal mengemaskini status. Sila cuba lagi.')
        console.error(error)
      }
    }

    localStorage.removeItem(STORAGE_KEY)
    setSedangJejak(false)
    setKeadaan('biasa')
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-sky-100 via-sky-50 to-white px-4 py-10">
      {/* Soft glow blobs behind the glass layer */}
      <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-sky-300/40 blur-3xl" />
      <div className="pointer-events-none absolute right-0 top-1/3 h-80 w-80 rounded-full bg-emerald-200/40 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-cyan-200/40 blur-3xl" />

      <div className="relative mx-auto max-w-2xl">
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/60 bg-white/40 px-5 py-4 shadow-lg backdrop-blur-md">
          <div className="flex items-center gap-3">
            <img src={apmLogo} alt="Logo APM" className="h-10 w-10 object-contain" />
            <h1 className="text-xl font-semibold text-neutral-900">{negeri}</h1>
          </div>

          <button
            onClick={() => navigate('/paras')}
            className="flex items-center gap-1 rounded-full border border-white/60 bg-white/40 px-3 py-1.5 text-xs font-medium text-neutral-700 backdrop-blur-md transition-colors hover:border-emerald-500 hover:text-emerald-700"
          >
            <ArrowLeft size={14} />
            Kembali
          </button>
        </div>

        <div className="mt-6 flex flex-col items-center gap-3 rounded-2xl border border-white/60 bg-white/40 p-6 shadow-lg backdrop-blur-md">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={sedangJejak ? handleTamatJejak : handleMulaJejak}
            disabled={mendapatkanGps}
            className={`flex items-center gap-2 rounded-full px-6 py-2.5 text-sm font-semibold text-white disabled:opacity-70 ${
              sedangJejak ? 'bg-red-600 hover:bg-red-700' : 'bg-emerald-700 hover:bg-emerald-800'
            }`}
          >
            {mendapatkanGps ? (
              <motion.span
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                className="flex"
              >
                <Loader2 size={16} />
              </motion.span>
            ) : (
              <>
                {sedangJejak && (
                  <motion.span
                    animate={{ opacity: [1, 0.3, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                    className="h-2 w-2 rounded-full bg-white"
                  />
                )}
                <Navigation size={16} />
              </>
            )}
            {mendapatkanGps ? 'Mendapatkan GPS...' : sedangJejak ? 'Tamat Jejak' : 'Mula Jejak'}
          </motion.button>

          {sedangJejak && (
            <div className="flex w-full flex-wrap gap-2">
              <motion.button
                type="button"
                whileTap={{ scale: 0.97 }}
                onClick={tekanRehat}
                disabled={menukarKeadaan || keadaan === 'kecemasan'}
                className={`flex flex-1 items-center justify-center gap-2 rounded-full border px-5 py-2.5 text-sm font-semibold transition-colors disabled:opacity-50 ${
                  keadaan === 'rehat'
                    ? 'border-amber-500 bg-amber-500 text-white'
                    : 'border-amber-300 bg-white/60 text-amber-700 hover:bg-amber-50'
                }`}
              >
                <Coffee size={16} />
                REHAT
              </motion.button>

              <motion.button
                type="button"
                whileTap={{ scale: 0.97 }}
                onClick={tekanKecemasan}
                disabled={menukarKeadaan}
                className={`flex flex-1 items-center justify-center gap-2 rounded-full border px-5 py-2.5 text-sm font-semibold transition-colors disabled:opacity-50 ${
                  keadaan === 'kecemasan'
                    ? 'animate-pulse border-red-600 bg-red-600 text-white'
                    : 'border-red-300 bg-white/60 text-red-700 hover:bg-red-50'
                }`}
              >
                <Siren size={16} />
                KECEMASAN
              </motion.button>
            </div>
          )}

          {ralat && <p className="text-sm text-red-600">{ralat}</p>}
        </div>

        <div className="mt-6 rounded-2xl border border-white/60 bg-white/40 p-4 shadow-lg backdrop-blur-md">
          <h2 className="mb-3 text-sm font-medium text-neutral-900">
            Peta lokasi — {negeri}
          </h2>
          <ParasMap points={lokasiAwam} center={posisiSaya ?? undefined} />
        </div>

        <ConfirmModal
          open={sahkanKecemasan}
          title="Isyarat Kecemasan"
          message="Hantar isyarat KECEMASAN kepada Pusat Kawalan? Gunakan hanya dalam keadaan sebenar."
          confirmLabel="Hantar"
          danger
          onConfirm={() => {
            setSahkanKecemasan(false)
            tukarKeadaan('kecemasan')
          }}
          onCancel={() => setSahkanKecemasan(false)}
        />
      </div>
    </div>
  )
}
